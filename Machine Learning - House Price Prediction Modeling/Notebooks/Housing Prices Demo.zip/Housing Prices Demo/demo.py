import os
os.system("bash install.sh")

import pickle
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from tkinter import Tk
from tkinter.filedialog import askopenfilename

catagorical_features = [
    "MSPUD",
    "Street",
    "CentralAir",
]

ordinal_features = [
    "ExterQual",
    "ExterCond",
    "BsmtQual",
    "BsmtCond",
    "HeatingQC",
    "KitchenQual",
    "FireplaceQu",
    "GarageQual",
    "GarageCond",
    "PoolQC",
    "Alley",
    "LotShape",
    "Utilities",
    "LandSlope",
    "BsmtExposure",
    "GarageFinish",
    "PavedDrive",
]

ordinal_features = []

numeric_features = [
    "LotFrontage",
    "LotArea",
    "OverallQual",
    "OverallCond",
    "YearBuilt",
    "YearRemodAdd",
    "MasVnrArea",
    "BsmtFinSF1",
    "BsmtFinSF2",
    "BsmtUnfSF",
    "TotalBsmtSF",
    "1stFlrSF",
    "2ndFlrSF",
    "LowQualFinSF",
    "GrLivArea",
    "BsmtFullBath",
    "BsmtHalfBath",
    "FullBath",
    "HalfBath",
    "BedroomAbvGr",
    "KitchenAbvGr",
    "TotRmsAbvGrd",
    "Fireplaces",
    #"GarageYrBlt",
    "GarageCars",
    "GarageArea",
    "WoodDeckSF",
    "OpenPorchSF",
    "EnclosedPorch",
    "3SsnPorch",
    "ScreenPorch",
    "PoolArea",
    #"MiscVal",    # separate this value based on MiscFeature
    "MiscFeature_Gar2",
    "MiscFeature_None",
    "MiscFeature_Othr",
    "MiscFeature_Shed",
    #"MiscFeature_Elev",
    #"MiscFeature_TenC",
    "MoSold",
    "YrSold",
]

def build_pipeline(imputer, scaler, encoder, estimator):
  numeric_transformer = Pipeline(steps=[
      ('imputer', imputer),
      ('scaler', scaler),
  ])

  preprocessor = ColumnTransformer(
      transformers=[('numeric', numeric_transformer, numeric_features + ordinal_features)],
      remainder = "passthrough"
  )

  pipeline = Pipeline(steps = [
    ('preprocessor', preprocessor),
    ('encoder', encoder),
    ('regressor', estimator)
  ])

  return pipeline

class CustomPipeline:
  def __init__(self, imputer, scaler, encoder, estimator, isKerasModel=False, epochs=1, **args):
    self.pipeline = build_pipeline(imputer, scaler, encoder, estimator)
    self.imputer = imputer
    self.scaler = scaler
    self.encoder = encoder
    self.estimator = estimator
    self.isKerasModel = isKerasModel
    self.epochs = epochs
  
  def fit(self, X, y):
    if (self.isKerasModel):
      self.pipeline[2].reset_states() 
      return self.pipeline.fit(X, y, regressor__epochs=self.epochs, regressor__verbose=0)
    else:
      return self.pipeline.fit(X, y)
  
  def predict(self, X):
    return self.pipeline.predict(X)

  def get_params(self, deep=False):
    if deep:
      return self.pipeline.get_params(deep).update({"imputer":self.imputer, "scaler":self.scaler, "encoder":self.encoder, "estimator":self.estimator, "isKerasModel":self.isKerasModel, "epochs":self.epochs})
    else:
      return {"imputer":self.imputer, "scaler":self.scaler, "encoder":self.encoder, "estimator":self.estimator, "isKerasModel":self.isKerasModel, "epochs":self.epochs}

### Start of script
print()

### Prompt user to select a pickle file model
Tk().withdraw()
load_model_msg = "Select the .pkl model to load"
print(load_model_msg)
model_filename = askopenfilename(title=load_model_msg, filetypes=(("pickle files","*.pkl"),("all files","*.*")))

### Prompt user to select
model = None
with open(model_filename, "rb") as file:
    model = pickle.load(file)
print("loaded", model_filename)

load_data_msg = "Select the .csv housing data to load"
print(load_data_msg)
data_filename = askopenfilename(title=load_data_msg, filetypes=(("csv files","*.csv"),("all files","*.*")))

df_demo = pd.read_csv(data_filename)
df_demo_ids = df_demo["Id"]
df_demo_prices = df_demo["SalePrice"]
df_demo.drop("Unnamed: 0", axis=1, inplace=True)
df_demo.drop("Id", axis=1, inplace=True)
df_demo.drop("SalePrice", axis=1, inplace=True)
print("loaded", data_filename)

demo_pred = model.predict(df_demo)

print(f'\nId\tPredicted Price\tActual Price\tError')
for i in range(len(df_demo_ids)):
  print(f'{df_demo_ids.get(i)}\t${"{:0.0f}".format(demo_pred[i])}\t\t${"{:0.0f}".format(df_demo_prices[i])}\t\t${"{:0.0f}".format(demo_pred[i]-df_demo_prices[i])}')